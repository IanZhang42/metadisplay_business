# Simulator startup failure — October 12, 2026

The user reported a built/installed simulator app that immediately crashed with:

```text
Follow-up SDK configuration failed; inspect configuration privately.
MWDATCore/Wearables.swift:308: Fatal error: Call configure() before attempting to access Wearables!
```

The app's catch block swallowed the configuration error and then constructed `FollowUpModel`, whose initializers access `Wearables.shared`. That was an application bug.

The supplied `mac-check.sh` also passed `CODE_SIGNING_ALLOWED=NO`. A [Meta maintainer explains the matching failure](https://github.com/facebook/meta-wearables-dat-ios/issues/197#issuecomment-4549647052): disabling simulator signing makes SDK keychain initialization fail. Their recommended remedy is simulator **ad-hoc signing**, with `CODE_SIGN_IDENTITY="-"`. The original reporter confirmed that this resolved their SDK bootstrap failure. That report was against an earlier SDK; the exact configuration error on this user's 1.0.1 build was hidden, so the next run still needs verification.

Changes in this kit:

- Both simulator build/test commands explicitly enable signing and use identity `-`. The simulator build performs `clean build` so the previously unsigned product is rebuilt.
- Startup constructs the model only after successful SDK configuration. `alreadyConfigured` is accepted as an initialized SDK; other errors show the SDK enum description/code on a failure screen and in the console.
- The failure screen does not touch `Wearables.shared`, record, or send.
- Two startup regression tests are authored. They verify that failed configuration cannot invoke the SDK-dependent model factory, and that successful configuration runs before model construction. They have not been executed on a Mac here.

The duplicate `DwaDisplayProtosSwift.DisplayRequest._StorageClass` warning refers to code inside Meta's `MWDATDisplay` and `MWDATMockDevice` binaries. These are distinct required products for mock display preview. This kit does not remove or rewrite vendor binaries. Its causal role is unverified; investigate it further if a fresh signed run still fails or exhibits casting problems. The immediate observed fatal follows the failed configuration and unguarded shared access.

## Apply to the existing Mac folder

Use the separate `FollowUpStartupFix.zip` and its `apply.sh`. It replaces only the four affected script/source/test files and saves backups under the existing kit's `build-evidence`. It does not replace the Xcode project, Apple signing settings, backend secrets or runtime data.

From the current `FollowUpDemo` directory, after extracting the fix ZIP in Downloads:

```sh
bash "$HOME/Downloads/FollowUpStartupFix/apply.sh" "$PWD"
```

Then rebuild/test in that same directory with the already selected iPhone simulator UUID:

```sh
SIMULATOR_ID="PASTE-YOUR-IPHONE-17-UUID" bash scripts/mac-check.sh
```

After a successful build/test, open the project and use Xcode's Run button with that simulator selected. If startup remains blocked, report the new on-screen SDK error or the `Follow-up SDK startup blocked:` console line. Do not send backend/Gmail credentials.

Current result: code corrected and syntax checked on Windows; fresh Mac compilation, simulator launch and native tests remain pending. Physical glasses/audio/locked-phone behavior remains untested. Live email stays disabled by default.
